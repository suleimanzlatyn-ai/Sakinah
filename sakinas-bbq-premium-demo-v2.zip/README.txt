SAKINAS BBQ TUALA — PREMIUM WEBSITE DEMO

Files:
- index.html: responsive website with animations and interactive components
- sakinas-bbq-logo.svg: editable vector logo

Features:
- Animated logo emblem, flame pulse, smooth hero movement, reveal transitions
- Scroll progress indicator, sticky navigation feedback, back-to-top control
- Searchable and category-filtered sample menu
- Editable order drawer: increase/decrease quantity, remove items, clear order
- WhatsApp order enquiry with itemised estimated total
- Reservation/group enquiry form via WhatsApp
- FAQ accordion, gallery, responsive navigation and reduced-motion support
- Basic metadata and accessible controls

IMPORTANT BEFORE LAUNCH:
- Menu items, descriptions and prices are illustrative placeholders; replace with the restaurant's actual menu.
- Photos are illustrative stock photos; replace with owner-approved photos of Sakinas BBQ Tuala.
- Confirm phone/WhatsApp number, location and operating hours with the owner.
- Orders and reservations are WhatsApp enquiries only; this demo does not store orders, take payments, or confirm bookings automatically.
- Testimonials and ratings should only be published if genuine and approved; this demo avoids fabricated customer reviews.
- Requires internet access for remote Unsplash photos and WhatsApp links.
